// đoạn này e tham khảo từ web geeksforgeeks
function togglePassword() {
  const passwordInput = document.getElementById("password");
  passwordInput.type = passwordInput.type === "password" ? "text" : "password";
}

function register(event) {
  event.preventDefault();

  const firstName = document.getElementById("firstName").value.trim();
  const lastName = document.getElementById("lastName").value.trim();
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();

  if (!firstName || !lastName || !email || !password) {
    alert("Please fill in all fields");
    return;
  }

  const users = JSON.parse(localStorage.getItem("users")) || [];

  const newUser = {
    fullname: `${firstName} ${lastName}`,
    email,
    password,
  };
  users.push(newUser);
  localStorage.setItem("users", JSON.stringify(users));

  alert("created successfully");
}

document.querySelector("form").addEventListener("submit", register);
